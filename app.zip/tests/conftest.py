import os
import tempfile
import pytest
from app import app
from database import init_db

@pytest.fixture
def client():
    # Create a temporary file to use as a database
    db_fd, db_path = tempfile.mkstemp()
    
    # Configure the app for testing
    app.config['TESTING'] = True
    app.config['DATABASE'] = db_path
    app.config['SECRET_KEY'] = 'test_secret'
    
    # Initialize the database
    init_db(db_path)
    
    with app.test_client() as client:
        with app.app_context():
            yield client
            
    # Cleanup
    os.close(db_fd)
    os.unlink(db_path)
