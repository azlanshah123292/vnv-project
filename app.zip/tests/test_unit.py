from database import get_db_connection
import sqlite3

def test_get_db_connection():
    """Unit test to verify database connection creation."""
    # using :memory: to creating a purely in-memory database for this unit test
    conn = get_db_connection(':memory:')
    assert isinstance(conn, sqlite3.Connection)
    conn.close()
