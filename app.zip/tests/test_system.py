import sqlite3
from app import app

def test_full_system_flow(client):
    """
    System Test:
    1. Register 'admin_user'.
    2. Elevate 'admin_user' to admin via backend (simulating manual entry).
    3. Login 'admin_user'.
    4. Add a Room.
    5. Logout.
    6. Register 'guest_user'.
    7. Login 'guest_user'.
    8. Book the new Room.
    9. Check Dashboard for booking.
    10. Cancel booking.
    """
    
    # 1. Register admin
    client.post('/register', data={'username': 'admin_user', 'password': 'adminpass'}, follow_redirects=True)
    
    # 2. Elevate to admin
    with app.app_context():
        db_path = app.config['DATABASE']
        conn = sqlite3.connect(db_path)
        conn.execute("UPDATE users SET role = 'admin' WHERE username = 'admin_user'")
        conn.commit()
        conn.close()
        
    # 3. Login admin
    client.post('/login', data={'username': 'admin_user', 'password': 'adminpass'}, follow_redirects=True)
    
    # 4. Add Room
    client.post('/add_room', data={
        'name': 'Test Room',
        'description': 'A nice test room',
        'price': '100',
        'image_url': 'test.jpg',
        'city': 'TestCity'
    }, follow_redirects=True)
    
    # 5. Logout
    client.get('/logout', follow_redirects=True)
    
    # 6. Register guest
    client.post('/register', data={'username': 'guest_user', 'password': 'guestpass'}, follow_redirects=True)
    
    # 7. Login guest
    client.post('/login', data={'username': 'guest_user', 'password': 'guestpass'}, follow_redirects=True)
    
    # 8. Book Room
    # first, get the room id. assuming it's 1 since it's fresh db
    room_id = 1
    response = client.post(f'/book/{room_id}', data={
        'start_date': '2023-01-01',
        'end_date': '2023-01-05',
        'payment_method': 'hotel'
    }, follow_redirects=True)
    assert b'Room booked successfully' in response.data
    
    # 9. Dashboard
    response = client.get('/dashboard')
    assert b'Test Room' in response.data
    
    # 10. Cancel Booking
    # booking id is likely 1
    booking_id = 1
    response = client.get(f'/cancel_booking/{booking_id}', follow_redirects=True)
    assert b'Booking cancelled' in response.data
    
    # Verify removal from dashboard
    response = client.get('/dashboard')
    assert b'Test Room' not in response.data
