import os
import unittest
import tempfile
from app import app, get_db
from database import init_db

class HotelPaymentTestCase(unittest.TestCase):
    def setUp(self):
        self.db_fd, self.db_path = tempfile.mkstemp()
        app.config['DATABASE'] = self.db_path
        app.config['TESTING'] = True
        self.client = app.test_client()
        
        with app.app_context():
            init_db(self.db_path)
            db = get_db()
            # Create a test user
            from werkzeug.security import generate_password_hash
            db.execute('INSERT INTO users (username, password, role) VALUES (?, ?, ?)',
                       ('testuser', generate_password_hash('testpass'), 'user'))
            # Create a test room
            db.execute('INSERT INTO rooms (name, description, price, image_url, city) VALUES (?, ?, ?, ?, ?)',
                       ('Test Room', 'A nice room', 100.0, 'img.jpg', 'Lahore'))
            db.commit()
            db.close()

    def tearDown(self):
        os.close(self.db_fd)
        os.unlink(self.db_path)

    def login(self, username, password):
        return self.client.post('/login', data=dict(
            username=username,
            password=password
        ), follow_redirects=True)

    def test_book_pay_at_hotel(self):
        self.login('testuser', 'testpass')
        response = self.client.post('/book/1', data=dict(
            start_date='2025-01-01',
            end_date='2025-01-05',
            payment_method='hotel'
        ), follow_redirects=True)
        
        self.assertIn(b'Room booked successfully!', response.data)
        self.assertIn(b'Hotel', response.data) # Check dashboard display
        self.assertIn(b'Pending', response.data)

    def test_book_pay_card(self):
        self.login('testuser', 'testpass')
        response = self.client.post('/book/1', data=dict(
            start_date='2025-02-01',
            end_date='2025-02-05',
            payment_method='card',
            card_number='1234',
            expiry='01/30',
            cvv='123'
        ), follow_redirects=True)
        
        self.assertIn(b'Room booked successfully!', response.data)
        self.assertIn(b'Card', response.data)
        self.assertIn(b'Paid', response.data)

if __name__ == '__main__':
    unittest.main()
