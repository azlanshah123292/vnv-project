import unittest
from unittest.mock import patch, mock_open, MagicMock
import runpy
import sys
import os

# We need to add the project root to sys.path if it's not already there
# to ensure imports work correctly during tests
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

class TestScripts(unittest.TestCase):
    
    def test_migrate_city(self):
        """Test migrate_city.py functionality."""
        from migrate_city import add_city_column
        import sqlite3
        
        # Success case
        with patch('sqlite3.connect') as mock_connect:
            add_city_column()
            mock_connect.assert_called_with('hotel.db')
            mock_connect.return_value.execute.assert_called()
            
        # Error case (column exists)
        with patch('sqlite3.connect') as mock_connect:
            mock_connect.return_value.execute.side_effect = sqlite3.OperationalError
            add_city_column()
            # Should not raise exception
            
    def test_migrate_city_main(self):
        """Test migrate_city.py __main__ block."""
        with patch('sqlite3.connect') as mock_connect:
            runpy.run_module('migrate_city', run_name='__main__')
            mock_connect.assert_called()
            mock_connect.return_value.execute.assert_called()

    def test_migrate_payments(self):
        """Test migrate_payments.py functionality."""
        from migrate_payments import add_payment_columns
        import sqlite3
        
        # Success case
        with patch('sqlite3.connect') as mock_connect:
            add_payment_columns()
            mock_connect.assert_called_with('hotel.db')
            
        # Error case 1: payment_method exists
        with patch('sqlite3.connect') as mock_connect:
            # We have two execute calls. 
            # 1. payment_method
            # 2. payment_status
            # We want first to fail, second to succeed
            mock_conn = mock_connect.return_value
            mock_conn.execute.side_effect = [sqlite3.OperationalError, None]
            add_payment_columns()
            
        # Error case 2: payment_status exists
        with patch('sqlite3.connect') as mock_connect:
            mock_conn = mock_connect.return_value
            mock_conn.execute.side_effect = [None, sqlite3.OperationalError]
            add_payment_columns()

    def test_migrate_payments_main(self):
        """Test migrate_payments.py __main__ block."""
        with patch('sqlite3.connect') as mock_connect:
            runpy.run_module('migrate_payments', run_name='__main__')
            mock_connect.assert_called()

    def test_seed_data(self):
        """Test seed_data.py functionality."""
        from seed_data import seed_rooms
        with patch('seed_data.get_db_connection') as mock_get_db:
             mock_conn = MagicMock()
             mock_get_db.return_value = mock_conn
             seed_rooms()
             assert mock_conn.execute.call_count >= 1
             mock_conn.commit.assert_called()
             mock_conn.close.assert_called()

    def test_seed_data_main(self):
         """Test seed_data.py __main__ block."""
         with patch('database.get_db_connection') as mock_get_db:
             mock_conn = MagicMock()
             mock_get_db.return_value = mock_conn
             runpy.run_module('seed_data', run_name='__main__')
             assert mock_get_db.called
             
    def test_download_images_func(self):
        """Test download_images.py individual download function."""
        from download_images import download_image
        
        with patch('requests.get') as mock_get, \
             patch('builtins.open', mock_open()) as mock_file:
            
            # Successful download
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.content = b'binary data'
            mock_get.return_value = mock_response
            
            download_image('http://example.com/img.jpg', 'img.jpg')
            
            mock_file.assert_called_with('static/images/img.jpg', 'wb')
            mock_file().write.assert_called_with(b'binary data')
            
            # Failed download (404)
            mock_response.status_code = 404
            mock_file.reset_mock()
            download_image('http://example.com/missing.jpg', 'missing.jpg')
            mock_file.assert_not_called()
            
            # Exception
            mock_get.side_effect = Exception("Network error")
            download_image('http://example.com/error.jpg', 'error.jpg')

    def test_download_images_main(self):
        """Test download_images.py main block."""
        with patch('os.path.exists') as mock_exists, \
             patch('os.makedirs') as mock_makedirs, \
             patch('requests.get') as mock_get, \
             patch('builtins.open', mock_open()) as mock_file:
             
             mock_exists.return_value = False
             mock_get.return_value.status_code = 200
             
             runpy.run_module('download_images', run_name='__main__')
             
             mock_makedirs.assert_called_with('static/images')
             assert mock_get.call_count >= 3
