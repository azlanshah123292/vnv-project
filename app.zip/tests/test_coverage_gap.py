import pytest
from database import update_admin_role, get_db_connection
from app import app
import sqlite3

def test_duplicate_registration(client):
    """Test registering the same username twice triggers IntegrityError handling."""
    client.post('/register', data={'username': 'dup_user', 'password': 'pass'}, follow_redirects=True)
    response = client.post('/register', data={'username': 'dup_user', 'password': 'pass'}, follow_redirects=True)
    assert b'Username already exists' in response.data

def test_index_city_filter(client):
    """Test the index page with a city filter."""
    # First add a room with a city
    with app.app_context():
        db_path = app.config['DATABASE']
        conn = sqlite3.connect(db_path)
        conn.execute("INSERT INTO rooms (name, price, city) VALUES ('City Room', 100, 'Paris')")
        conn.commit()
        conn.close()
        
    response = client.get('/?city=Paris')
    assert b'City Room' in response.data
    
    response = client.get('/?city=London')
    assert b'City Room' not in response.data

def test_unauthenticated_access(client):
    """Test accessing protected routes without login."""
    routes = ['/dashboard', '/add_room', '/book/1', '/cancel_booking/1']
    for route in routes:
        response = client.get(route, follow_redirects=True)
        # Should redirect to login
        assert b'Login' in response.data or b'login' in response.data.lower()

def test_add_room_forbidden(client):
    """Test accessing add_room as a non-admin user."""
    # Register and login as regular user
    client.post('/register', data={'username': 'regular', 'password': 'pass'}, follow_redirects=True)
    client.post('/login', data={'username': 'regular', 'password': 'pass'}, follow_redirects=True)
    
    response = client.get('/add_room', follow_redirects=True)
    # Should be redirected to login (or index depending on implementation? 
    # Logic says: if 'user_id' not in session or session.get('role') != 'admin': return redirect(url_for('login'))
    assert b'Login' in response.data or b'login' in response.data.lower()

def test_admin_dashboard(client):
    """Test the admin view of the dashboard."""
    # Register and make admin
    client.post('/register', data={'username': 'admin2', 'password': 'pass'}, follow_redirects=True)
    
    with app.app_context():
        db_path = app.config['DATABASE']
        conn = sqlite3.connect(db_path)
        conn.execute("UPDATE users SET role = 'admin' WHERE username = 'admin2'")
        # Add a booking to see it
        # Need a user, a room, and a booking
        # User is admin2 (id 1)
        # Create a room
        cursor = conn.execute("INSERT INTO rooms (name, price) VALUES ('AdminRoom', 200)")
        room_id = cursor.lastrowid
        conn.execute(f"INSERT INTO bookings (user_id, room_id, start_date, end_date) VALUES (1, {room_id}, '2022-01-01', '2022-01-02')")
        conn.commit()
        conn.close()
        
    client.post('/login', data={'username': 'admin2', 'password': 'pass'}, follow_redirects=True)
    response = client.get('/dashboard')
    assert b'AdminRoom' in response.data

def test_database_update_admin_role():
    """Test the standalone update_admin_role function."""
    # This function uses the constant DATABASE_NAME from database.py.
    # We need to make sure it doesn't break anything or actually run against the real db if possible.
    # However, since it hardcodes 'hotel.db', running it might affect the real file if it exists.
    # Tests run in a temp dir or we should patch it.
    # Given the user wants 100% coverage, we must execute it.
    # We can patch sqlite3.connect.
    
    from unittest.mock import patch
    
    with patch('database.sqlite3.connect') as mock_connect:
        update_admin_role()
        mock_connect.assert_called_with('hotel.db')
        
def test_get_requests(client):
    """Test GET requests for forms."""
    client.post('/register', data={'username': 'u', 'password': 'p'}, follow_redirects=True)
    client.post('/login', data={'username': 'u', 'password': 'p'}, follow_redirects=True)
    
    # Add room GET (requires admin, so let's skip or login as admin)
    # Book room GET
    # First create a room
    with app.app_context():
        db_path = app.config['DATABASE']
        conn = sqlite3.connect(db_path)
        conn.execute("INSERT INTO rooms (name, price) VALUES ('GetRoom', 300)")
        conn.commit()
        conn.close()
        
    response = client.get('/book/1')
    assert response.status_code == 200
    assert b'GetRoom' in response.data

def test_add_room_get(client):
    """Test the add_room page (GET) as admin."""
    # Register and make admin
    client.post('/register', data={'username': 'admin3', 'password': 'pass'}, follow_redirects=True)
    
    with app.app_context():
        db_path = app.config['DATABASE']
        conn = sqlite3.connect(db_path)
        conn.execute("UPDATE users SET role = 'admin' WHERE username = 'admin3'")
        conn.commit()
        conn.close()
        
    client.post('/login', data={'username': 'admin3', 'password': 'pass'}, follow_redirects=True)
    response = client.get('/add_room')
    assert response.status_code == 200
    assert b'Add New Room' in response.data

def test_app_main():
    """Test the database.py and app.py __main__ blocks."""
    from unittest.mock import patch
    import runpy
    import sys
    
    # Test database.py main
    # Patch sqlite3.connect to avoid real db ops (or side effects on hotel.db) 
    # and to verify something happened
    with patch('sqlite3.connect') as mock_connect:
        try:
             # run_module looks for modules in sys.path. 
             # Current directory should be in sys.path during pytest.
             runpy.run_module('database', run_name='__main__')
        except ImportError:
             pass
        # database.py calls init_db -> get_db_connection -> sqlite3.connect
        assert mock_connect.called
        
    # Test app.py main
    # Patch Flask.run to avoid blocking server
    with patch('flask.Flask.run') as mock_run:
        try:
            runpy.run_module('app', run_name='__main__')
        except ImportError:
            pass
        assert mock_run.called
