def test_home_page(client):
    """Integration test: Home page should return 200 OK."""
    response = client.get('/')
    assert response.status_code == 200

def test_register_and_login(client):
    """Integration test: Register a user, then login."""
    
    # 1. Register
    response = client.post('/register', data={
        'username': 'newuser',
        'password': 'password123'
    }, follow_redirects=True)
    assert response.status_code == 200
    assert b'Registration successful' in response.data or b'Login' in response.data

    # 2. Login
    response = client.post('/login', data={
        'username': 'newuser',
        'password': 'password123'
    }, follow_redirects=True)
    assert response.status_code == 200
    # On success, we redirect to index, which should presumably show the user is logged in
    # However, since we don't have the template content handy, we rely on status code and implicit success
    # We can check session if we want, but checking response is more 'integration' style
    
def test_login_invalid(client):
    """Integration test: Login with wrong credentials."""
    response = client.post('/login', data={
        'username': 'nonexistent',
        'password': 'wrongpassword'
    }, follow_redirects=True)
    assert b'Invalid username or password' in response.data
